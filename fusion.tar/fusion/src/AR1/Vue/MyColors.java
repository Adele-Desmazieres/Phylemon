package AR1.Vue;

import java.awt.*;

public class MyColors {
    public static Color rose = new Color(247, 185, 221);
    public static Color violet = new Color(200, 148, 237);
    public static Color bleu = new Color (187, 230, 246);
    public static Color jaune = new Color(247, 242, 222);

    public static Color jauneBordure = new Color(250, 229, 152);
    public static Color fond = new Color(247, 212, 250);
}
